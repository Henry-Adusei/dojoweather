var removal = document.querySelector("#cookietext")
function remove_def() {
    removal.remove();
}

var change1 = document.querySelector('.tempx1')
var change2 = document.querySelector('.tempx2')
var change3 = document.querySelector('.tempx3')
var change4 = document.querySelector('.tempx4')
var change5 = document.querySelector('.tempx5')
var change6 = document.querySelector('.tempx6')
var change7 = document.querySelector('.tempx7')
var change8 = document.querySelector('.tempx8')
function change_temp(element) {
    change1.innerText = '75°'
    change2.innerText = '65°'
    change3.innerText = '80°'
    change4.innerText = '66°'
    change5.innerText = '69°'
    change6.innerText = '61°'
    change7.innerText = '78°'
    change8.innerText = '70°'
}